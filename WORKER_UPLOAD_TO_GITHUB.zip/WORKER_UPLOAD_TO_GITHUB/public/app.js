'use strict';
(() => {
 const $=id=>document.getElementById(id);
 let allCustomers=[], shownCreds=null, toastTimer;
 const display=(id,yes)=>$(id).classList.toggle('hidden',!yes);
 function toast(text){$('toast').textContent=text;display('toast',true);clearTimeout(toastTimer);toastTimer=setTimeout(()=>display('toast',false),4300);}
 async function request(url,{method='GET',body}={}){
   let r=await fetch(url,{method,credentials:'same-origin',headers:{'Content-Type':'application/json','X-Nexox-Client':'1'},body:body?JSON.stringify(body):undefined,cache:'no-store'});
   let data;try{data=await r.json();}catch{throw Error('Server response was not valid');}
   if(!r.ok)throw Error(data.error||'Request failed');return data;
 }
 function errorMessage(e){return e?.message||'Connection failed';}
 function secureGenerate(){
  const alphabet='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#$%';let a=new Uint32Array(19);crypto.getRandomValues(a);return 'Nx!'+Array.from(a,n=>alphabet[n%alphabet.length]).join('');
 }
 function hideCredentials(){shownCreds=null;$('resultEmail').textContent='';$('resultPassword').textContent='';display('credentialModal',false);}
 function revealCredentials(email,pass,isReset=false){shownCreds={email,pass};$('credentialTitle').textContent=isReset?'Password reset successful!':'Account created!';$('resultEmail').textContent=email;$('resultPassword').textContent=pass;display('credentialModal',true);}
 async function init(){
  try{let me=await request('/api/admin/me');showAdmin(me.username);}catch{showLogin();}
 }
 function showAdmin(username){$('adminName').textContent=username;display('loginView',false);display('dashboard',true);loadCustomers();loadAudit();loadProvider();}
 function showLogin(){display('dashboard',false);display('loginView',true);$('loginPass').value='';}
 async function loadCustomers(){
  try{let data=await request('/api/admin/customers');allCustomers=data.customers;updateMetrics();renderCustomers();}
  catch(e){if(errorMessage(e).includes('login'))showLogin();else toast(errorMessage(e));}
 }
 function updateMetrics(){$('totalCount').textContent=allCustomers.length;$('activeCount').textContent=allCustomers.filter(x=>x.status==='active').length;$('disabledCount').textContent=allCustomers.filter(x=>x.status==='disabled').length;}
 function el(t,className,text){let n=document.createElement(t);if(className)n.className=className;if(text!==undefined)n.textContent=text;return n;}
 function renderCustomers(){
   const list=$('customerList');list.replaceChildren();const search=$('searchUsers').value.trim().toLowerCase(),filter=$('filterStatus').value;
   const customers=allCustomers.filter(x=>x.email.includes(search)&&(filter==='all'||x.status===filter));
   if(!customers.length){list.append(el('p','empty-state','কোনো কাস্টমার পাওয়া যায়নি।'));return;}
   for(const c of customers){
    let row=el('div','customer-row'),identity=el('div','customer-identity'),avatar=el('div','avatar',c.email.slice(0,1).toUpperCase()),who=el('div');
    who.append(el('div','customer-email',c.email),el('div','customer-sub',`#${c.id} · ${new Date(c.created_at).toLocaleDateString('en-GB')} ${c.must_change_password?'· Password change required':''}`));identity.append(avatar,who);
    let actions=el('div','customer-actions'),status=el('span','status '+c.status,c.status==='active'?'● Active':'● Disabled');
    let reset=el('button','action-btn','Reset Password');reset.type='button';reset.addEventListener('click',()=>resetPassword(c));
    let toggle=el('button','action-btn '+(c.status==='active'?'danger':'good'),c.status==='active'?'Disable':'Enable');toggle.type='button';toggle.addEventListener('click',()=>toggleCustomer(c));
    actions.append(status,reset,toggle);row.append(identity,actions);list.append(row);
   }
 }
 async function loadAudit(){
  const list=$('auditList');list.replaceChildren();try{
    let data=await request('/api/admin/audit');if(!data.activity.length){list.append(el('p','empty-state','No recent admin changes.'));return;}
    for(let a of data.activity){let r=el('div','audit-row'),name=el('strong','',a.action.replaceAll('_',' ').replace(/\b\w/g,m=>m.toUpperCase())+' · Customer #'+a.customer_id),time=el('span','',new Date(a.at).toLocaleString('en-GB'));r.append(name,time);list.append(r);}
  }catch(e){list.append(el('p','empty-state','Could not load activity'));}
 }
 async function resetPassword(c){
  if(!confirm(`Reset password for ${c.email}? Old customer login sessions will be invalidated.`))return;
  try{let d=await request(`/api/admin/customers/${c.id}/reset-password`,{method:'POST',body:{}});revealCredentials(d.email,d.temporary_password,true);loadCustomers();loadAudit();}
  catch(e){toast(errorMessage(e));}
 }
 async function toggleCustomer(c){
  const next=c.status==='active'?'disabled':'active';if(!confirm(`${next==='disabled'?'Disable':'Enable'} ${c.email}?`))return;
  try{await request(`/api/admin/customers/${c.id}/status`,{method:'POST',body:{status:next}});toast(`Account ${next}`);loadCustomers();loadAudit();}
  catch(e){toast(errorMessage(e));}
 }
 $('loginForm').addEventListener('submit',async e=>{e.preventDefault();let b=$('loginSubmit');b.disabled=true;$('loginError').textContent='';try{
   let d=await request('/api/admin/login',{method:'POST',body:{username:$('loginUser').value.trim(),password:$('loginPass').value}});showAdmin(d.username);
  }catch(err){$('loginError').textContent=errorMessage(err);}finally{b.disabled=false;}
 });
 $('toggleLoginPass').addEventListener('click',()=>{const p=$('loginPass');p.type=p.type==='password'?'text':'password';$('toggleLoginPass').textContent=p.type==='password'?'Show':'Hide';});
 $('createForm').addEventListener('submit',async e=>{e.preventDefault();let b=$('createBtn');b.disabled=true;try{
   const email=$('createEmail').value.trim(),password=$('createPassword').value;
   let d=await request('/api/admin/customers',{method:'POST',body:{email,...(password?{password}:{})}});$('createForm').reset();revealCredentials(d.customer.email,d.temporary_password);await loadCustomers();loadAudit();
  }catch(err){toast(errorMessage(err));}finally{b.disabled=false;}
 });
 $('generatePassword').addEventListener('click',()=>{$('createPassword').value=secureGenerate();});
 $('closeModal').addEventListener('click',hideCredentials);
 $('credentialModal').addEventListener('click',e=>{if(e.target===$('credentialModal'))hideCredentials();});
 $('copyCredentials').addEventListener('click',async()=>{
   if(!shownCreds)return;let txt=`Nexox Mobile AI\nEmail: ${shownCreds.email}\nTemporary Password: ${shownCreds.pass}\nPlease change your password at first login.`;
   try{await navigator.clipboard.writeText(txt);toast('Login details copied. Share privately.');}catch{toast('Clipboard not available; select and copy details manually.');}
 });
 $('logoutBtn').addEventListener('click',async()=>{try{await request('/api/admin/logout',{method:'POST'});}finally{showLogin();}});
 $('refreshBtn').addEventListener('click',()=>{loadCustomers();loadAudit();});
 $('searchUsers').addEventListener('input',renderCustomers);
 $('filterStatus').addEventListener('change',renderCustomers);
 $('newCustomerBtn').addEventListener('click',()=>{$('createPanel').scrollIntoView({behavior:'smooth'});$('createEmail').focus();});
 const navs={navHome:'.intro',navCreate:'#createPanel',navUsers:'#customerList',navSecurity:'#providerPanel'};
 for(const [id,target] of Object.entries(navs))$(id).addEventListener('click',()=>{document.querySelector(target).scrollIntoView({behavior:'smooth',block:'start'});document.querySelectorAll('.nav-button').forEach(x=>x.classList.remove('selected'));$(id).classList.add('selected');});
 const emptySlot=kind=>({kind,format:kind==='normal'?'gemini':'openai_chat',model:kind==='normal'?'gemini-2.5-flash':'',endpoint:'',key_header:kind==='normal'?'x-goog-api-key':'Authorization',key_prefix:kind==='normal'?'':'Bearer ',request_template:'',response_path:kind==='normal'?'':'choices.0.message.content'});
 let activeProvider='normal',viewKind='normal',savedSlots={normal:{configured:false},gateway:{configured:false}};
 const kindName=kind=>kind==='normal'?'Normal API':'Provider Gateway';
 function showGatewayCustom(){display('gatewayCustom',$('gatewayFormat').value==='custom_json');}
 function switchProvider(kind){
  viewKind=kind;$('normalTab').classList.toggle('active',kind==='normal');$('gatewayTab').classList.toggle('active',kind==='gateway');display('normalFields',kind==='normal');display('gatewayFields',kind==='gateway');
  const c=savedSlots[kind]?.configured?savedSlots[kind]:emptySlot(kind);
  $('providerModel').value=c.model||'';$('providerKey').value='';$('providerKey').required=!savedSlots[kind]?.configured;
  $('gatewayEndpoint').value=c.endpoint||'';$('gatewayFormat').value=c.format||'openai_chat';$('gatewayHeader').value=c.key_header||'Authorization';$('gatewayPrefix').value=c.key_prefix??'Bearer ';
  $('gatewayTemplate').value=c.request_template||'';$('gatewayResponsePath').value=c.response_path||'choices.0.message.content';showGatewayCustom();
  $('providerSelectionNote').textContent=`${kindName(kind)}: ${savedSlots[kind]?.configured?'Saved':'Not configured'} · ${activeProvider===kind?'ACTIVE for customers':'Not active'}; Saving does not switch customers automatically.`;
  $('providerActivate').disabled=!savedSlots[kind]?.configured||activeProvider===kind;
  $('providerActivate').textContent=activeProvider===kind?'✓ Currently Active':`Activate ${kindName(kind)} for Customers`;
 }
 $('normalTab').addEventListener('click',()=>switchProvider('normal'));
 $('gatewayTab').addEventListener('click',()=>switchProvider('gateway'));
 $('gatewayFormat').addEventListener('change',()=>{showGatewayCustom();if(viewKind==='gateway')$('gatewayResponsePath').value=$('gatewayFormat').value==='gemini'?'candidates.0.content.parts.0.text':'choices.0.message.content';});
 async function loadProvider(){
  try{const data=await request('/api/admin/providers');savedSlots=data.slots;activeProvider=data.active;
   const current=data.slots?.[activeProvider];$('providerStatus').textContent=`ACTIVE: ${kindName(activeProvider)} · ${current?.configured?current.model:'Not configured'} · Normal: ${data.slots.normal.configured?'saved':'empty'} · Gateway: ${data.slots.gateway.configured?'saved':'empty'}`;
   switchProvider(viewKind);
  }catch(e){$('providerStatus').textContent='Error: '+errorMessage(e);}
 }
 $('providerForm').addEventListener('submit',async e=>{e.preventDefault();const b=$('providerSave');b.disabled=true;
  try{const data={kind:viewKind,model:$('providerModel').value.trim(),api_key:$('providerKey').value.trim()};
   if(viewKind==='gateway')Object.assign(data,{endpoint:$('gatewayEndpoint').value.trim(),format:$('gatewayFormat').value,key_header:$('gatewayHeader').value.trim(),key_prefix:$('gatewayPrefix').value,request_template:$('gatewayTemplate').value,response_path:$('gatewayResponsePath').value.trim()});
   await request('/api/admin/providers',{method:'POST',body:data});$('providerKey').value='';toast(`${kindName(viewKind)} securely saved`);await loadProvider();loadAudit();
  }catch(err){toast(errorMessage(err));}finally{b.disabled=false;}
 });
 $('providerActivate').addEventListener('click',async()=>{
  if(!confirm(`Activate ${kindName(viewKind)} for ALL active customers?`))return;
  try{await request('/api/admin/providers/activate',{method:'POST',body:{kind:viewKind}});toast('Active AI provider updated');await loadProvider();loadAudit();}catch(err){toast(errorMessage(err));}
 });
 $('adminPasswordForm').addEventListener('submit',async e=>{e.preventDefault();try{
  await request('/api/admin/change-password',{method:'POST',body:{current_password:$('oldAdminPassword').value,new_password:$('newAdminPassword').value}});
  $('adminPasswordForm').reset();toast('✓ Admin password updated');loadAudit();
 }catch(err){toast(errorMessage(err));}});
 window.addEventListener('keydown'  ,e=>{if(e.key==='Escape')hideCredentials();});
 init();
})();
