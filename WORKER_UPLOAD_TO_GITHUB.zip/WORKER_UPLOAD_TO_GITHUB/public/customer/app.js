'use strict';
(()=>{
const $=s=>document.getElementById(s);
let token=sessionStorage.getItem('nx_token')||'',email=sessionStorage.getItem('nx_email')||'',mustChange=false,recognizer=null;
function show(el,yes){$(el).classList.toggle('hidden',!yes)}
function status(el,message,good=false){$(el).textContent=message;$(el).style.color=good?'#0b956b':'#e34b56'}
async function api(endpoint,method='GET',body){
 let r=await fetch(endpoint,{method,headers:{'Content-Type':'application/json','X-Nexox-Client':'1',...(token?{Authorization:'Bearer '+token}:{})},body:body?JSON.stringify(body):undefined,cache:'no-store'});
 let d;try{d=await r.json()}catch{throw Error('Server is unavailable')}if(!r.ok)throw Error(d.error||'Server error');return d;
}
function tab(name){for(const t of ['home','chat','tasks','settings'])show(t+'Tab',t===name);
 document.querySelectorAll('.nav').forEach(el=>el.classList.toggle('active',el.dataset.tab===name));}
function logout(){token='';email='';sessionStorage.removeItem('nx_token');sessionStorage.removeItem('nx_email');show('mainView',false);show('loginView',true);$('password').value='';}
async function initialize(){if(!token)return;
 try{const d=await api('/api/customer/me');email=d.email;mustChange=!!d.must_change_password;show('loginView',false);show('mainView',true);$('welcomeEmail').textContent=email;$('accountEmail').textContent=email;loadProvider();if(mustChange){tab('settings');status('changeStatus','প্রথমে তোমার প্রাথমিক পাসওয়ার্ড পরিবর্তন করো।');}}
 catch{logout()}}
async function loadProvider(){try{const d=await api('/api/customer/ai/status');$('providerStatus').textContent=d.provider.configured?`✓ ${d.provider.name} · ${d.provider.model} · Daily limit ${d.daily_limit}`:'⚠ Admin এখনো AI Gateway যুক্ত করেননি।';}catch(e){$('providerStatus').textContent=e.message}}
$('loginForm').addEventListener('submit',async ev=>{ev.preventDefault();const b=$('loginBtn');b.disabled=true;try{let d=await api('/api/customer/login','POST',{email:$('email').value.trim(),password:$('password').value});token=d.access_token;email=d.customer.email;mustChange=!!d.customer.must_change_password;sessionStorage.setItem('nx_token',token);sessionStorage.setItem('nx_email',email);await initialize();}catch(e){status('loginStatus',e.message)}finally{b.disabled=false}});
$('changeForm').addEventListener('submit',async ev=>{ev.preventDefault();try{await api('/api/customer/change-password','POST',{current_password:$('oldPass').value,new_password:$('newPass').value});mustChange=false;$('changeForm').reset();status('changeStatus','✓ পাসওয়ার্ড পরিবর্তন হয়েছে',true)}catch(e){status('changeStatus',e.message)}});
$('logoutBtn').onclick=async()=>{try{await api('/api/customer/logout','POST')}catch{}logout()};
function bubble(who,text){const el=document.createElement('div');el.className='bubble '+who;el.textContent=text;$('messages').appendChild(el);$('messages').scrollTop=$('messages').scrollHeight;return el;}
$('chatForm').addEventListener('submit',async ev=>{ev.preventDefault();const msg=$('messageInput').value.trim();if(!msg)return;
 if(mustChange){tab('settings');status('changeStatus','AI ব্যবহার করার আগে পাসওয়ার্ড পরিবর্তন করো');return;}
 bubble('user',msg);$('messageInput').value='';$('sendBtn').disabled=true;let loading=bubble('bot','AI উত্তর প্রস্তুত করছে...');
 try{let d=await api('/api/customer/ai/chat','POST',{message:msg});loading.textContent=d.answer;}catch(e){loading.textContent='⚠ '+e.message}finally{$('sendBtn').disabled=false;$('messages').scrollTop=$('messages').scrollHeight;}
});
function voice(){const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!SR){$('voiceSupport').textContent='এই Android WebView-তে Speech Recognition নেই। Native Voice module দরকার।';tab('chat');return;}
 try{if(recognizer){recognizer.stop();recognizer=null;return;}
 recognizer=new SR();recognizer.lang='bn-BD';recognizer.interimResults=false;recognizer.maxAlternatives=1;
 recognizer.onresult=e=>{let text=e.results[0][0].transcript;$('messageInput').value=text;tab('chat');$('voiceSupport').textContent='Voice recognized. Press Send to share with Gemini.'};
 recognizer.onerror=e=>{$('voiceSupport').textContent='Voice error: '+e.error};recognizer.onend=()=>{recognizer=null};recognizer.start();$('voiceSupport').textContent='Listening...';}catch(e){$('voiceSupport').textContent=e.message;}}
$('homeMic').onclick=voice;$('micBtn').onclick=voice;$('quickVoice').onclick=voice;
$('openChat').onclick=()=>tab('chat');$('quickChat').onclick=()=>tab('chat');$('quickTasks').onclick=()=>tab('tasks');$('quickSafety').onclick=()=>tab('settings');
$('clearChat').onclick=()=>{$('messages').replaceChildren();bubble('bot','Local chat cleared. New conversation ready.');};
for(const el of document.querySelectorAll('[data-tab]'))el.addEventListener('click',()=>tab(el.dataset.tab));
initialize();
})();
