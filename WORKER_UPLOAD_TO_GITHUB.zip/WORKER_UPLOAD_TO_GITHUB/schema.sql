-- Run once: wrangler d1 execute nexox-free --remote --file=./schema.sql
CREATE TABLE IF NOT EXISTS admins (id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS customers (id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','disabled')), must_change_password INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY,actor_type TEXT NOT NULL,actor_id INTEGER NOT NULL,expires_at INTEGER NOT NULL,created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_session_ttl ON sessions(expires_at);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, action TEXT NOT NULL,customer_id INTEGER,at TEXT NOT NULL,details TEXT NOT NULL DEFAULT '');
CREATE TABLE IF NOT EXISTS ai_providers(kind TEXT PRIMARY KEY CHECK(kind IN ('normal','gateway')),format TEXT NOT NULL,model TEXT NOT NULL,endpoint TEXT NOT NULL,key_header TEXT NOT NULL,key_prefix TEXT NOT NULL,request_template TEXT NOT NULL,response_path TEXT NOT NULL,encrypted_key TEXT NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS ai_settings(id INTEGER PRIMARY KEY CHECK(id=1),active_kind TEXT NOT NULL CHECK(active_kind IN ('normal','gateway')));
INSERT OR IGNORE INTO ai_settings(id,active_kind) VALUES(1,'normal');
CREATE TABLE IF NOT EXISTS ai_usage(id INTEGER PRIMARY KEY,customer_id INTEGER NOT NULL,created_at TEXT NOT NULL,status TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_usage_daily ON ai_usage(customer_id,created_at);
CREATE TABLE IF NOT EXISTS rate_limits(id TEXT PRIMARY KEY,attempts INTEGER NOT NULL,until_ms INTEGER NOT NULL);
