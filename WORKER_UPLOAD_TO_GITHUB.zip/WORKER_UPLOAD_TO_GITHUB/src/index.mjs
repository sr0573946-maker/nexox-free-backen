// Nexox Free Backend — Cloudflare Workers + D1 (no Node hosting)
// Two independent AI connection slots: normal Gemini API and custom Provider Gateway.
// Secrets are NEVER sent to a customer or embedded in the APK.
const te = new TextEncoder();
const td = new TextDecoder();
const utcNow = () => new Date().toISOString();
const logId = () => crypto.randomUUID();
const base64 = bytes => btoa(String.fromCharCode(...bytes)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
const unbase64 = s => Uint8Array.from(atob(s.replace(/-/g,'+').replace(/_/g,'/')+'='.repeat((4-s.length%4)%4)),c=>c.charCodeAt(0));
const hexBytes = s => Uint8Array.from((s.match(/.{2}/g)||[]),x=>parseInt(x,16));
const randomToken = () => base64(crypto.getRandomValues(new Uint8Array(32)));
async function sha(s) { return base64(new Uint8Array(await crypto.subtle.digest('SHA-256', te.encode(s)))); }
async function pbkdf(password,salt,iterations=100000){const key=await crypto.subtle.importKey('raw',te.encode(password),'PBKDF2',false,['deriveBits']);return new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',salt,iterations,hash:'SHA-256'},key,256));}
async function hashPassword(p){const salt=crypto.getRandomValues(new Uint8Array(16));const dig=await pbkdf(p,salt);return `pbkdf2$100000$${base64(salt)}$${base64(dig)}`;}
function safeEq(a,b){if(a.length!==b.length)return false;let d=0;for(let i=0;i<a.length;i++)d|=a[i]^b[i];return d===0;}
async function verifyPassword(p,stored){try{const [alg,itr,s,d]=stored.split('$');if(alg!=='pbkdf2'||!Number.isInteger(+itr)||+itr<50000||+itr>500000)return false;const x=await pbkdf(p,unbase64(s),+itr);return safeEq(x,unbase64(d));}catch{return false;}}
async function aesKey(secret){if(!/^[a-f\d]{64}$/i.test(secret||''))throw Error('Missing 64-hex-character NEXOX_MASTER_KEY');return crypto.subtle.importKey('raw',hexBytes(secret),{name:'AES-GCM'},false,['encrypt','decrypt']);}
async function encrypt(value,secret){const iv=crypto.getRandomValues(new Uint8Array(12));const data=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv},await aesKey(secret),te.encode(value)));return base64(iv)+'.'+base64(data);}
async function decrypt(value,secret){const [i,c]=value.split('.');return td.decode(await crypto.subtle.decrypt({name:'AES-GCM',iv:unbase64(i)},await aesKey(secret),unbase64(c)));}
function reply(data,status=200,headers={}) {return new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff','referrer-policy':'no-referrer','x-frame-options':'DENY',...headers}});}
const err=(m,status=400)=>reply({error:m},status);
function validEmail(x){return typeof x==='string'&&x.length<=254&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(x);}
function validPassword(x){return typeof x==='string'&&x.length>=12&&x.length<=128;}
function validModel(s){return typeof s==='string' && /^[-a-zA-Z0-9_.]{3,120}$/.test(s);}
async function bodyJson(req){const s=await req.text();if(te.encode(s).length>16000)throw Error('Request too large');let d=JSON.parse(s||'{}');if(!d||Array.isArray(d)||typeof d!=='object')throw Error('Invalid JSON');return d;}
const q=(env,sql,...params)=>env.DB.prepare(sql).bind(...params);
async function record(env,action,customerId=null,details=''){await q(env,'INSERT INTO audit(action,customer_id,at,details) VALUES(?,?,?,?)',action,customerId,utcNow(),details).run();}
function passGenerate(){return 'Nx!'+randomToken().slice(0,22);}
function allowedOrigin(req){const o=req.headers.get('origin');return !o || o===new URL(req.url).origin;}
function bearer(req){return /^Bearer ([A-Za-z0-9_-]{20,180})$/.exec(req.headers.get('authorization')||'')?.[1]||null;}
function cookieToken(req){return /(?:^|;\s*)nx_admin=([A-Za-z0-9_-]{20,180})/.exec(req.headers.get('cookie')||'')?.[1]||null;}
function cookie(value,maxAge){return `nx_admin=${value}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=${maxAge}`;}
async function ensureAdmin(env){
 const existing=await q(env,'SELECT id FROM admins LIMIT 1').first();if(existing)return;
 const username=env.ADMIN_USERNAME,password=env.ADMIN_PASSWORD;
 if(!/^[a-zA-Z0-9_.-]{3,50}$/.test(username||'') || !validPassword(password)||!/[A-Za-z]/.test(password)||!/\d/.test(password))throw Error('Set ADMIN_USERNAME and strong ADMIN_PASSWORD as Worker Secrets before first use');
 await q(env,'INSERT OR IGNORE INTO admins(username,password_hash,created_at) VALUES(?,?,?)',username,await hashPassword(password),utcNow()).run();
}
async function session(env,actor,id){const token=randomToken(),ttl=actor==='admin'?8*3600:7*86400;await q(env,'INSERT INTO sessions(token_hash,actor_type,actor_id,expires_at,created_at) VALUES(?,?,?,?,?)',await sha(token),actor,id,Date.now()+ttl*1000,utcNow()).run();return {token,ttl};}
async function auth(env,req,type){const token=type==='admin'?cookieToken(req):bearer(req);if(!token)return null;const row=await q(env,'SELECT actor_id FROM sessions WHERE token_hash=? AND actor_type=? AND expires_at>?',await sha(token),type,Date.now()).first();if(!row)return null;
 const u=type==='admin'?await q(env,'SELECT id,username FROM admins WHERE id=?',row.actor_id).first():await q(env,'SELECT id,email,status,must_change_password FROM customers WHERE id=?',row.actor_id).first();if(!u||type==='customer'&&u.status!=='active')return null;return {user:u,token};}
async function limiter(env,key){const h=await sha(key),row=await q(env,'SELECT attempts,until_ms FROM rate_limits WHERE id=?',h).first();return !row||Date.now()>row.until_ms||row.attempts<8;}
async function failed(env,key){const h=await sha(key);await q(env,`INSERT INTO rate_limits(id,attempts,until_ms) VALUES(?,1,?) ON CONFLICT(id) DO UPDATE SET attempts=CASE WHEN until_ms<? THEN 1 ELSE attempts+1 END,until_ms=CASE WHEN until_ms<? THEN excluded.until_ms ELSE until_ms END`,h,Date.now()+900000,Date.now(),Date.now()).run();}
async function resetAttempts(env,key){await q(env,'DELETE FROM rate_limits WHERE id=?',await sha(key)).run();}
function safeGatewayURL(str){try{const u=new URL(str);if(u.protocol!=='https:'||u.username||u.password||u.hash||u.search) return false;if(!u.hostname.includes('.')||u.hostname==='localhost'||u.hostname.endsWith('.local')||/^(127\.|10\.|192\.168\.|169\.254\.|0\.|172\.(1[6-9]|2\d|3[01])\.)/.test(u.hostname))return false;return str.length<=600;}catch{return false;}}
const normalConfig={kind:'normal',format:'gemini',model:'gemini-2.5-flash',endpoint:'',key_header:'x-goog-api-key',key_prefix:'',request_template:'',response_path:''};
const gatewayConfig={kind:'gateway',format:'openai_chat',model:'',endpoint:'',key_header:'Authorization',key_prefix:'Bearer ',request_template:'',response_path:'choices.0.message.content'};
const PROVIDER_SELECT='SELECT kind,format,model,endpoint,key_header,key_prefix,request_template,response_path,updated_at FROM ai_providers';
async function providerStatuses(env){const entries=await q(env,PROVIDER_SELECT).all(),s={normal:{configured:false},gateway:{configured:false}};for(const p of entries.results||[])s[p.kind]={...p,configured:true};const active=await q(env,'SELECT active_kind FROM ai_settings WHERE id=1').first();return {active:active?.active_kind||'normal',slots:s};}
function textPath(obj,p){let x=obj;for(const part of p.split('.')){if(x==null)return '';if(!/^\w+$/.test(part))return '';x=x[part];}return typeof x==='string'?x:typeof x==='number'?String(x):'';}
function formatBody(cfg,message){
 if(cfg.format==='gemini')return {systemInstruction:{parts:[{text:'You are Nexox Mobile AI. Respond clearly in Bengali or English. You cannot yet control other Android apps. Never pretend an action happened.'}]},contents:[{role:'user',parts:[{text:message}]}],generationConfig:{maxOutputTokens:640}};
 if(cfg.format==='openai_chat')return {model:cfg.model,messages:[{role:'system',content:'You are Nexox Mobile AI; reply in Bengali or English. Do not claim phone control is available.'},{role:'user',content:message}],max_tokens:640};
 if(cfg.format==='custom_json'){
   const template=cfg.request_template||'{"model":"{{model}}","message":"{{message}}"}';
   const obj=JSON.parse(template);
   const walk=v=>typeof v==='string'?v.replaceAll('{{model}}',cfg.model).replaceAll('{{message}}',message):Array.isArray(v)?v.map(walk):v&&typeof v==='object'?Object.fromEntries(Object.entries(v).map(([k,x])=>[k,walk(x)])):v;
   return walk(obj);
 }
 throw Error('Unknown API format');
}
async function modelCall(env,cfg,message,timeoutMs=18000){
 const key=await decrypt(cfg.encrypted_key,env.NEXOX_MASTER_KEY);
 const url=cfg.kind==='normal'?`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(cfg.model)}:generateContent`:cfg.endpoint;
 if(cfg.kind==='gateway'&&!safeGatewayURL(url))throw Error('Invalid Gateway URL');
 const h={'Content-Type':'application/json'};h[cfg.kind==='normal'?'x-goog-api-key':cfg.key_header]=cfg.kind==='normal'?key:(cfg.key_prefix||'')+key;
 const abort=new AbortController();const timer=setTimeout(()=>abort.abort(),timeoutMs);
 try{
  const r=await fetch(url,{method:'POST',headers:h,body:JSON.stringify(formatBody(cfg,message)),signal:abort.signal});
  const data=await r.json().catch(()=>({}));
  if(!r.ok){let e=new Error(r.status===429?'AI quota or rate limit reached':r.status>=500?'AI provider is busy':`Provider returned status ${r.status}`);e.status=r.status===429?429:r.status>=500?503:502;throw e;}
  const answer=cfg.format==='gemini'?(data.candidates||[]).flatMap(x=>x.content?.parts||[]).map(x=>x.text||'').join('\n').trim():textPath(data,cfg.response_path||'choices.0.message.content').trim();
  if(!answer)throw Error('Provider gave no readable answer. Check response path.');
  return {answer:answer.slice(0,18000),model:cfg.model,provider:cfg.kind};
 }finally{clearTimeout(timer);}
}
async function handle(req,env){
 const url=new URL(req.url),path=url.pathname,method=req.method;
 if(method==='GET'&&path==='/health')return reply({ok:true,service:'Nexox Free API',version:'2.0',hosting:'workers-free'});
 if(!path.startsWith('/api/'))return env.ASSETS.fetch(req);
 if(!allowedOrigin(req))return err('Cross-origin requests not accepted',403);
 if(method!=='GET'&&method!=='POST')return err('Unsupported method',405);
 if(method==='POST'&&!['application/json','application/json; charset=utf-8'].includes((req.headers.get('content-type')||'').toLowerCase()))return err('JSON required',415);
 if(method==='POST'&&path==='/api/admin/login'){
  await ensureAdmin(env);const b=await bodyJson(req),username=String(b.username||''),pass=String(b.password||'');const id='ad:'+username.toLowerCase()+':'+(req.headers.get('cf-connecting-ip')||'unknown');if(!(await limiter(env,id)))return err('Too many attempts',429);
  const row=await q(env,'SELECT id,password_hash FROM admins WHERE username=?',username).first();if(!row||!await verifyPassword(pass,row.password_hash)){await failed(env,id);return err('Wrong username or password',401);}await resetAttempts(env,id);const s=await session(env,'admin',row.id);return reply({ok:true,username,expires_at:new Date(Date.now()+s.ttl*1000).toISOString()},200,{'Set-Cookie':cookie(s.token,s.ttl)});
 }
 if(method==='POST'&&path==='/api/customer/login'){
  const b=await bodyJson(req),email=String(b.email||'').trim().toLowerCase(),pass=String(b.password||'');const id='cu:'+email+':'+(req.headers.get('cf-connecting-ip')||'unknown');if(!(await limiter(env,id)))return err('Too many attempts',429);
  const row=await q(env,'SELECT * FROM customers WHERE email=?',email).first();if(!row||!await verifyPassword(pass,row.password_hash)){await failed(env,id);return err('Wrong email or password',401);}if(row.status!=='active')return err('Account disabled',403);await resetAttempts(env,id);const s=await session(env,'customer',row.id);return reply({access_token:s.token,expires_at:new Date(Date.now()+s.ttl*1000).toISOString(),customer:{id:row.id,email:row.email,must_change_password:!!row.must_change_password}});
 }
 if(path.startsWith('/api/admin/')){
  const a=await auth(env,req,'admin');if(!a)return err('Admin login required',401);const adminId=a.user.id;
  if(path==='/api/admin/me'&&method==='GET')return reply({username:a.user.username});
  if(path==='/api/admin/logout'&&method==='POST'){await q(env,'DELETE FROM sessions WHERE token_hash=?',await sha(a.token)).run();return reply({ok:true},200,{'Set-Cookie':cookie('',0)});}
  if(path==='/api/admin/change-password'&&method==='POST'){
   const b=await bodyJson(req);if(!validPassword(b.new_password)||!/[A-Za-z]/.test(b.new_password)||!/\d/.test(b.new_password))return err('New password must have 12+ characters, letters and digits');const row=await q(env,'SELECT password_hash FROM admins WHERE id=?',adminId).first();if(!await verifyPassword(String(b.current_password||''),row.password_hash))return err('Wrong current password',401);if(await verifyPassword(b.new_password,row.password_hash))return err('Choose a different password');await q(env,'UPDATE admins SET password_hash=? WHERE id=?',await hashPassword(b.new_password),adminId).run();await q(env,'DELETE FROM sessions WHERE actor_type=? AND actor_id=? AND token_hash<>?','admin',adminId,await sha(a.token)).run();await record(env,'admin_password_changed');return reply({ok:true});
  }
  if(path==='/api/admin/customers'&&method==='GET'){const x=await q(env,'SELECT id,email,status,must_change_password,created_at,updated_at FROM customers ORDER BY id DESC LIMIT 1000').all();return reply({customers:x.results||[]});}
  if(path==='/api/admin/customers'&&method==='POST'){
   const b=await bodyJson(req),email=String(b.email||'').trim().toLowerCase(),pass=b.password||passGenerate();if(!validEmail(email))return err('Valid email required');if(!validPassword(pass))return err('Password must be 12-128 characters');const found=await q(env,'SELECT id FROM customers WHERE email=?',email).first();if(found)return err('Email already exists',409);
   const n=utcNow();const result=await q(env,'INSERT INTO customers(email,password_hash,status,must_change_password,created_at,updated_at) VALUES(?,?,?,?,?,?)',email,await hashPassword(pass),'active',1,n,n).run();const id=result.meta.last_row_id;await record(env,'created',id);return reply({customer:{id,email,status:'active',must_change_password:true},temporary_password:pass},201);
  }
  const m=/^\/api\/admin\/customers\/(\d+)\/(status|reset-password)$/.exec(path);
  if(m&&method==='POST'){
   const id=Number(m[1]),b=await bodyJson(req),user=await q(env,'SELECT email FROM customers WHERE id=?',id).first();if(!user)return err('Customer not found',404);
   if(m[2]==='status'){if(!['active','disabled'].includes(b.status))return err('Invalid status');await q(env,'UPDATE customers SET status=?,updated_at=? WHERE id=?',b.status,utcNow(),id).run();if(b.status==='disabled')await q(env,'DELETE FROM sessions WHERE actor_type=? AND actor_id=?','customer',id).run();await record(env,b.status==='active'?'enabled':'disabled',id);return reply({ok:true,id,status:b.status});}
   const pass=b.password||passGenerate();if(!validPassword(pass))return err('Password must be 12-128 characters');await q(env,'UPDATE customers SET password_hash=?,must_change_password=1,updated_at=? WHERE id=?',await hashPassword(pass),utcNow(),id).run();await q(env,'DELETE FROM sessions WHERE actor_type=? AND actor_id=?','customer',id).run();await record(env,'password_reset',id);return reply({ok:true,email:user.email,temporary_password:pass});
  }
  if(path==='/api/admin/audit'&&method==='GET'){const x=await q(env,'SELECT id,action,customer_id,at FROM audit ORDER BY id DESC LIMIT 50').all();return reply({activity:x.results||[]});}
  if(path==='/api/admin/providers'&&method==='GET')return reply(await providerStatuses(env));
  if(path==='/api/admin/providers'&&method==='POST'){
   const b=await bodyJson(req);if(!['normal','gateway'].includes(b.kind)||!validModel(b.model))return err('Choose valid provider slot/model');
   const format=b.kind==='normal'?'gemini':b.format;if(b.kind==='gateway'&&!['gemini','openai_chat','custom_json'].includes(format))return err('Choose valid Gateway JSON format');
   const endpoint=b.kind==='normal'?'':String(b.endpoint||'').trim();if(b.kind==='gateway'&&!safeGatewayURL(endpoint))return err('Valid external HTTPS Gateway URL required');
   const keyHeader=b.kind==='normal'?'x-goog-api-key':String(b.key_header||'Authorization').trim();if(!/^[A-Za-z][A-Za-z0-9-]{0,60}$/.test(keyHeader)||/^(cookie|host|content-length|content-type|origin|referer)$/i.test(keyHeader))return err('Invalid authentication header');
   const prefix=b.kind==='normal'?'':String(b.key_prefix??'Bearer ');if(prefix.length>80||/[\r\n]/.test(prefix))return err('Invalid prefix');
   const requestTemplate=b.kind==='gateway'&&format==='custom_json'?String(b.request_template||''):'';if(requestTemplate.length>3500)return err('JSON template too large');if(requestTemplate){try{JSON.parse(requestTemplate);}catch{return err('Request template must be valid JSON');}}
   const responsePath=b.kind==='normal'?'':String(b.response_path|| (format==='gemini'?'candidates.0.content.parts.0.text':'choices.0.message.content'));if(b.kind==='gateway'&&(responsePath.length>150||!/^\w+(\.\w+)*$/.test(responsePath)))return err('Invalid response path');
   const old=await q(env,'SELECT encrypted_key FROM ai_providers WHERE kind=?',b.kind).first();const apiKey=typeof b.api_key==='string'?b.api_key.trim():'';
   if(!apiKey&&!old)return err('API Key required the first time');if(apiKey&&(apiKey.length<12||apiKey.length>2000||/[\r\n]/.test(apiKey)))return err('Invalid API key');
   const ciphertext=apiKey?await encrypt(apiKey,env.NEXOX_MASTER_KEY):old.encrypted_key;
   await q(env,`INSERT INTO ai_providers(kind,format,model,endpoint,key_header,key_prefix,request_template,response_path,encrypted_key,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(kind) DO UPDATE SET format=excluded.format,model=excluded.model,endpoint=excluded.endpoint,key_header=excluded.key_header,key_prefix=excluded.key_prefix,request_template=excluded.request_template,response_path=excluded.response_path,encrypted_key=excluded.encrypted_key,updated_at=excluded.updated_at`,b.kind,format,b.model,endpoint,keyHeader,prefix,requestTemplate,responsePath,ciphertext,utcNow()).run();await record(env,'provider_saved',null,b.kind);return reply(await providerStatuses(env));
  }
  if(path==='/api/admin/providers/activate'&&method==='POST'){
   const b=await bodyJson(req),kind=b.kind;if(!['normal','gateway'].includes(kind))return err('Invalid provider slot');if(!await q(env,'SELECT kind FROM ai_providers WHERE kind=?',kind).first())return err('Configure provider before activating',400);
   await q(env,'INSERT INTO ai_settings(id,active_kind) VALUES(1,?) ON CONFLICT(id) DO UPDATE SET active_kind=excluded.active_kind',kind).run();await record(env,'provider_activated',null,kind);return reply(await providerStatuses(env));
  }
  if(path==='/api/admin/ai-usage'&&method==='GET'){const t=new Date(Date.now()-86400000).toISOString();const x=await q(env,'SELECT COUNT(*) AS total,COUNT(DISTINCT customer_id) AS customers FROM ai_usage WHERE created_at>?',t).first();return reply({last_24h:x});}
  if(path==='/api/admin/provider'&&method==='GET'){const s=await providerStatuses(env);return reply({configured:!!s.slots[s.active]?.configured,name:s.active,model:s.slots[s.active]?.model,updated_at:s.slots[s.active]?.updated_at});}
 }
 if(path.startsWith('/api/customer/')){
  const c=await auth(env,req,'customer');if(!c)return err('Customer login required',401);
  if(path==='/api/customer/me'&&method==='GET')return reply({id:c.user.id,email:c.user.email,status:c.user.status,must_change_password:!!c.user.must_change_password});
  if(path==='/api/customer/logout'&&method==='POST'){await q(env,'DELETE FROM sessions WHERE token_hash=?',await sha(c.token)).run();return reply({ok:true});}
  if(path==='/api/customer/change-password'&&method==='POST'){
   const b=await bodyJson(req);if(!validPassword(b.new_password))return err('New password must be 12-128 characters');const x=await q(env,'SELECT password_hash FROM customers WHERE id=?',c.user.id).first();if(!await verifyPassword(String(b.current_password||''),x.password_hash))return err('Wrong current password',401);if(await verifyPassword(b.new_password,x.password_hash))return err('Choose a different password');await q(env,'UPDATE customers SET password_hash=?,must_change_password=0,updated_at=? WHERE id=?',await hashPassword(b.new_password),utcNow(),c.user.id).run();await q(env,'DELETE FROM sessions WHERE actor_type=? AND actor_id=? AND token_hash<>?','customer',c.user.id,await sha(c.token)).run();return reply({ok:true});
  }
  if(path==='/api/customer/ai/status'&&method==='GET'){const s=await providerStatuses(env);return reply({provider:{configured:!!s.slots[s.active]?.configured,name:s.active,model:s.slots[s.active]?.model},daily_limit:Number(env.AI_DAILY_LIMIT||40)});}
  if(path==='/api/customer/ai/chat'&&method==='POST'){
   if(c.user.must_change_password)return err('Change your temporary password first',403);const b=await bodyJson(req),message=String(b.message||'').trim();if(!message||message.length>2500)return err('Message must be 1-2500 characters');
   const t=new Date();t.setUTCHours(0,0,0,0);const used=await q(env,'SELECT COUNT(*) AS n FROM ai_usage WHERE customer_id=? AND created_at>=?',c.user.id,t.toISOString()).first();if(used.n>=Math.min(100,Number(env.AI_DAILY_LIMIT||40)))return err('Daily AI request limit reached',429);
   const setting=await providerStatuses(env);if(!setting.slots[setting.active]?.configured)return err('AI provider is not configured by Admin',503);
   const p=await q(env,'SELECT * FROM ai_providers WHERE kind=?',setting.active).first();let response;try{response=await modelCall(env,p,message);}catch(e){await q(env,'INSERT INTO ai_usage(customer_id,created_at,status) VALUES(?,?,?)',c.user.id,utcNow(),'error').run();return err(e.message||'AI connection failed',e.status||503);}
   await q(env,'INSERT INTO ai_usage(customer_id,created_at,status) VALUES(?,?,?)',c.user.id,utcNow(),'ok').run();return reply(response);
  }
 }
 return err('Not found',404);
}
export default {async fetch(req,env){try{return await handle(req,env);}catch(e){console.error('Nexox internal error',e?.message);return err('Server configuration or request error',500);}}};
export const testHelpers = {hashPassword,verifyPassword,encrypt,decrypt,formatBody,textPath,safeGatewayURL};
